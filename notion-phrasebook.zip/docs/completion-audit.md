# 完成度監査レポート

監査日：2026-07-24  
ブランチ：main（ローカル2コミット未プッシュ）

---

## 品質チェック結果

| チェック | 結果 |
|---|---|
| `npm run lint` | ✅ PASS |
| `npm run typecheck` | ✅ PASS |
| `npm run test` | ✅ PASS（6テスト） |
| `npm run build` | ✅ PASS（全13ルート生成） |

---

## 分類別 発見事項

### Blocker（公開前に必ず修正）

#### B-1：認証が完全未実装
- **状況**：`next-auth` が dependencies に存在、`README.md` にも記載、`src/app/api/auth/[...nextauth]/` ディレクトリも存在するが `route.ts` が空。`src/middleware.ts` が存在しない。
- **影響**：現在は **誰でも全APIルートにアクセス可能**。`/api/study` や `/api/ingest` が無認証で叩ける。個人用とはいえ公開 URL を知られると Notion DB を書き換えられる。
- **対応**：Auth.js v5 の route handler と middleware を実装。`AUTH_ALLOWED_EMAIL` でメール制限。

#### B-2：PWA 未実装
- **状況**：`manifest.json` なし、Service Worker なし、PWA アイコンなし、`public/` フォルダ空。`next-pwa` パッケージもインストールされていない（README には記載あり）。`next.config.ts` も空。
- **影響**：ホーム画面追加・オフラインキャッシュ・インストールプロンプトが一切動作しない。要件定義「PWA」を未達。
- **対応**：`next-pwa` インストール、`manifest.json` 作成（name / icons / theme_color など）、`next.config.ts` に withPWA 設定、PWA アイコン（192x192, 512x512）用意。

#### B-3：未コミットの Phase 4 実装
- **状況**：`git status` で以下が未コミット。
  - `src/lib/ai/extract.ts`
  - `src/lib/notion/ingest.ts`
  - `src/app/api/ingest/route.ts`
  - `src/app/ingest/page.tsx`
  - `src/hooks/useIngest.ts`
  - `.env.example`, `package.json`, `package-lock.json`, `src/app/page.tsx` の変更
- **対応**：コミットして origin に push する。

---

### Important（できれば公開前に修正）

#### I-1：フォントが実際にロードされない
- **状況**：`globals.css` で `Inter`, `Noto Sans JP`, `Source Serif 4` を指定しているが、Google Fonts の `<link>` タグも `next/font` も設定されていない。
- **影響**：端末にフォントが入っていない場合（特に Noto Sans JP / Source Serif 4）、`system-ui` / `Georgia` にフォールバック。デザインが崩れる可能性。
- **対応**：`layout.tsx` で `next/font/google` を使うか、`<link rel="preconnect" / rel="stylesheet">` を `<head>` に追加。

#### I-2：`/api/ingest` のタイムアウトリスク
- **状況**：`claude-opus-4-8` + adaptive thinking + 長文テキストの処理時間は数十秒になり得る。Vercel Serverless Function のデフォルト実行時間は 10 秒（Pro でも 60 秒がデフォルト）。
- **影響**：長文トランスクリプトで 504 Gateway Timeout。
- **対応**：`vercel.json` に `{ "functions": { "src/app/api/ingest/route.ts": { "maxDuration": 120 } } }` を追加（要 Vercel Pro）、またはモデルを Haiku に切り替えるか、Edge Runtime への移行を検討。

#### I-3：`notion-ids.ts` に `server-only` ガードなし
- **状況**：`NOTION_DB` に DB ID（環境変数）を格納しているが、ファイル先頭に `import 'server-only'` がない。
- **影響**：誰かが誤ってクライアントコンポーネントから `import` した場合、`NOTION_PHRASE_DB_ID` などの値がブラウザに露出する。DB ID 自体は公開しても致命的ではないが、原則として保護すべき。
- **対応**：ファイル先頭に `import 'server-only'` を追加。

#### I-4：`srs/config.ts` / `srs/algorithm.ts` に `server-only` ガードなし
- **状況**：`srs/config.ts` は `process.env.SRS_*` を参照。両ファイルとも `server-only` ガードなし。
- **影響**：クライアントバンドルに含まれる可能性。`SRS_*` 環境変数の値は機密ではないが、バンドルサイズ増加と原則違反。
- **対応**：両ファイルに `import 'server-only'` を追加（ただし `__tests__/srs-algorithm.test.ts` がテスト環境から import しているため要確認）。

#### I-5：Review Log に `PREVIOUS_INTERVAL` / `NEXT_INTERVAL` が未書込
- **状況**：`REVIEW_LOG_PROPS` に `PREVIOUS_INTERVAL` / `NEXT_INTERVAL` が定義されているが、`review-log.ts` の `writeReviewLog` で書き込んでいない。
- **影響**：Review Log の分析用データが不完全。後から間隔の推移が追えない。
- **対応**：`writeReviewLog` の引数に `previousInterval` / `nextInterval` を追加して書き込む、または不要なら schema 定数を削除。

#### I-6：`SentenceFlashCard` で Tailwind クラスとインラインスタイルが混在
- **状況**：`SentenceFlashCard.tsx` の外側 `div` に `className="flex flex-col gap-6 w-full"` を使用。他のコンポーネントはすべてインラインスタイルのみ。
- **影響**：スタイルの責務が不明確。Tailwind の purge 対象外になるリスク。
- **対応**：インラインスタイルに統一（`display: 'flex', flexDirection: 'column', gap: 24, width: '100%'`）。

#### I-7：git push 未実施
- **状況**：ローカルに 2 コミット（Phase 2, 3 相当）が積まれているが `origin/main` に未プッシュ。
- **影響**：リモートにバックアップがない。
- **対応**：コミット後に `git push`。

---

### Improvement（公開後でもよい）

#### Im-1：12px フォントが CLAUDE.md 規約に抵触
- **状況**：CLAUDE.md「補助テキスト 14px 未満禁止」に対し、以下で `fontSize: 12` を使用。
  - `phrase/page.tsx`（同期ステータス）
  - `script/page.tsx`（ステータスラベル）
  - `script/sentence/page.tsx`（同期ステータス）
  - `components/card/CardFront.tsx`, `CardBack.tsx`（EN / JA ラベル）
  - `components/card/SentenceFlashCard.tsx`（EN / JA ラベル）
  - `ingest/page.tsx`（文字数カウンター、登録済ラベル）
- **判断**：カードの "EN" / "JA" ラベルは意匠的なバッジであり、規約の「補助テキスト」とは別扱いとも解釈可能。ただし、同期ステータスの 12px は 14px に上げることが望ましい。

#### Im-2：テストカバレッジが薄い
- **状況**：テストは `srs-algorithm.test.ts` の 6 テストのみ。API ルート・コンポーネント・Notion ラッパーのテストなし。
- **対応**：`normalizePhrase`（`ingest.ts`）、`mapPageToPhrase`（`phrase-db.ts`）のユニットテストを追加。

#### Im-3：`/api/sync` の命名と実態の乖離
- **状況**：`implementation-plan.md` で「差分同期」と説明しているが、実態は全件 GET。`/api/phrases` などに改名するか、doc を更新するのが明確。

#### Im-4：`ingest/page.tsx` の `reset()` タイミング
- **状況**：submit 時に即 `reset()` を呼んでいるため、前の結果が消えてからローディングになる（一瞬フォームが再表示される）。
- **対応**：`isPending` 中は結果を保持したままオーバーレイするか、`reset()` を `onSuccess` / `onError` コールバック前ではなく後で呼ぶ。

#### Im-5：`ingest/page.tsx` の文字数上限がハードコード
- **状況**：`MAX_CHARS = 8000` が定数として埋め込まれている。Claude API の実際の token 上限や利用シナリオと連動していない。

#### Im-6：`source_type` の select 値が Notion 側で未定義の可能性
- **状況**：`ingest.ts` で `{ select: { name: 'AI Transcript' } }` を書き込んでいるが、Notion の select プロパティに 'AI Transcript' が事前定義されていない場合の挙動が不明。
- **補足**：Notion API は未定義の select 値を自動作成する仕様なので実際は動作するが、初回実行時に確認推奨。

---

## ディレクトリ構成と責務 — 評価

```
src/
├── app/
│   ├── api/        ✅ サーバー側のみ。Notionトークンは漏れていない
│   ├── phrase/     ✅ フレーズ学習画面
│   ├── script/     ✅ スクリプト一覧・全文・1文SRS
│   ├── ingest/     ✅ AI取り込みUI（ホーム非表示）
│   └── page.tsx    ✅ ホーム
├── components/     ✅ カード・ボタンUIコンポーネント
├── hooks/          ✅ TanStack Query wrappers
├── lib/
│   ├── notion/     ✅ Notion SDK wrapper（server-only ガードあり）
│   ├── ai/         ✅ Claude API wrapper（server-only ガード あり）
│   ├── srs/        ⚠️ server-only ガードなし
│   └── schema/     ⚠️ server-only ガードなし（notion-ids.ts）
└── types/          ✅ TypeScript 型定義
```

---

## セキュリティ評価

| 項目 | 状態 |
|---|---|
| NOTION_TOKEN のクライアント露出 | ✅ なし（すべて API Routes 内） |
| `.env.local` の Git 追跡 | ✅ .gitignore で除外、未追跡を確認済み |
| ANTHROPIC_API_KEY のクライアント露出 | ✅ なし（server-only） |
| 認証ガード（middleware） | ❌ 未実装 |
| 会話全文・トークンのログ出力 | ✅ なし |

---

## Notion 冪等性・重複排除

| 機能 | 冪等性 |
|---|---|
| フレーズ登録（ingest） | ✅ `Normalized Phrase` で重複チェック |
| Review Log 書込 | ✅ `LOG_ENTRY`（sessionId:itemId）で重複チェック |
| SRS 更新 | ✅ 同一 pageId に対して上書き（幂等） |
| Script 同期 | Notion 手動登録のため該当なし |

---

## 受け入れ条件チェックリスト

### コア機能

- [x] フレーズDB から本日の復習カードを取得する
- [x] 「覚えた」「忘れた」で間隔反復 (SM-2 簡略版) を更新する
- [x] EN→JA / JA→EN の両方向学習に対応する
- [x] Review Log に学習記録を書き込む（冪等チェックあり）
- [x] Script Library の一覧を表示する
- [x] Script 全文を表示する
- [x] Script の文章を1文ずつ SRS 学習する
- [x] Script のステータス（Draft / Memorizing / Perfect）を自動更新する
- [ ] **PWA としてホーム画面に追加できる**（manifest なし）
- [ ] **オフラインでキャッシュを参照できる**（Service Worker なし）

### 非機能

- [ ] **認証：本人以外アクセス不可**（middleware 未実装）
- [x] NOTION_TOKEN がブラウザに露出しない
- [x] lint / typecheck / test / build すべて通過
- [x] カラーパレットが CLAUDE.md 規定に準拠
- [x] `prefers-color-scheme` ダークモード対応
- [x] `prefers-reduced-motion` 対応
- [x] 390px 幅での横スクロールなし
- [x] 主要操作が画面下部に配置（親指が届く範囲）
- [ ] **Inter / Noto Sans JP / Source Serif 4 フォントが実際にロード**（`<link>` / `next/font` なし）
- [x] Notion DB ID・プロパティ名が `notion-ids.ts` に集約
- [x] 重複フレーズ登録の排除（Normalized Phrase による dedup）

### Phase 4（AI取り込み）

- [x] トランスクリプト貼付けで AI がフレーズ抽出
- [x] 重複フレーズはスキップして新規のみ Notion 登録
- [x] ホーム画面には非表示（直 URL でアクセス可能）
- [ ] **タイムアウト対策**（Vercel maxDuration 未設定）
- [ ] ANTHROPIC_API_KEY の `.env.local` 設定（ユーザー作業）

---

## 総括

| カテゴリ | 件数 |
|---|---|
| Blocker | 3 件 |
| Important | 7 件 |
| Improvement | 6 件 |

**本番公開を妨げる最大の問題は B-1（認証）と B-2（PWA）。**  
コア学習機能（フレーズSRS・Script SRS）は完動しており、Notion 連携・SRS アルゴリズム・冪等性はすべて正常。認証と PWA を実装すれば要件定義の主要受け入れ条件を満たせる状態にある。
