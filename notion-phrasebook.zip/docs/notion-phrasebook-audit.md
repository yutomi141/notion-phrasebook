# notion-phrasebook 詳細監査レポート

監査日: 2026-07-24
対象: 添付された `notion-phrasebook.zip`

## 結論

現状は「画面と主要処理の骨格が完成したMVP」ですが、**本番公開可能な完成状態ではありません**。特に認証、学習セッション、Mastered後の復習、依存関係の再現性に公開前修正が必要です。

## 監査範囲と制約

- ソース、API、認証、Notion連携、SRS、PWA、UI、ドキュメントを静的レビュー
- 実トークンや秘密鍵がZIP内にないことを確認
- PWAアイコン2点を目視確認
- 配色コントラストを計算
- `npm ci`、lint、typecheck、test、buildを実行しようとした
- `npm ci`はlockfile不整合で失敗。依存取得もサンドボックスのネットワーク制限で完了しなかったため、実アプリの起動・ブラウザ目視確認は実施できていない

---

## Blocker — 公開前に必ず修正

### B-1 認証Cookieの存在だけでアクセスを許可している

**場所:** `src/proxy.ts:22-34`

`authjs.session-token`または`__Secure-authjs.session-token`という名前のCookieが存在するだけで通過します。署名・有効期限・ユーザー本人性を検証していないため、任意のCookie値を設定したリクエストで保護ページ/APIへ到達できる可能性があります。

**修正:** Auth.jsの`auth()`でセッションを検証するproxy/middlewareに置き換える。重要な書込APIでもセッションと許可メールを再検証する。

### B-2 書込APIがクライアント送信のカード状態と任意page IDを信用している

**場所:** `src/app/api/study/route.ts:20-46`、`src/app/api/sentence-study/route.ts:34-65`

クライアントが送る`intervalDays`、`correctStreak`、回数、`itemId`をそのまま使用しています。値の改ざん、古い画面・複数端末による更新消失、共有済みの別NotionページIDへの誤更新が可能です。`result`も列挙値検証がなく、`forgotten`以外は実質remembered扱いになります。

**修正:** サーバー側で対象ページを取得し、対象DB所属を検証して現在値から計算する。入力をruntime schemaで検証する。イベントIDを導入し、同一レビューを冪等に処理する。

### B-3 最終カードでセッション完了にならない／途中カードを飛ばし得る

**場所:** `src/app/phrase/page.tsx:45-69`、`src/app/script/sentence/page.tsx:48-72`、`src/hooks/useStudyCards.ts:36-38`、`src/hooks/useScript.ts:78-81`

最終回答時は`cardIndex`を増やさないため、`cardIndex >= total`にならず完了画面へ遷移しません。一方、回答ごとにqueryをinvalidateして期限対象リストを再取得するため、配列が縮んだ状態でindexだけ増え、カードを飛ばす可能性があります。

**修正:** セッション開始時にカード配列を固定する。回答ごとに期限一覧を再フェッチしない。`completedCount`または明示的な`finished`状態を使い、最終回答後に必ず終了画面へ遷移する。

### B-4 Mastered／Doneを次回以降まったく出題しない

**場所:** `src/lib/notion/phrase-db.ts:66-103`、`src/lib/notion/sentences-db.ts:57-92`

期限抽出条件がNew/ReviewingまたはNot started/In progressのみで、Mastered/Doneを除外しています。MasteredにもNext Reviewを保存しているのに、その日が来ても二度と出題されません。

**修正:** 全ステータスについて`Next Review <= 今日`を対象にする。新規はNext Review空でも対象にする。Mastered後にforgottenならReviewingへ戻すテストを追加する。

### B-5 lockfile不整合でクリーンインストールできない

`npm ci`が以下で失敗しました。

- `Missing: @emnapi/runtime@1.11.2 from lock file`
- `Missing: @emnapi/core@1.11.2 from lock file`

CI・別端末・デプロイで再現できない可能性があります。

**修正:** Node/npmバージョンを固定し、`node_modules`とlockfileをクリーン生成して、空環境で`npm ci`が成功することを確認してからlockfileをコミットする。

---

## Important — 公開前修正を推奨

### I-1 Scriptのステータス遷移が要件どおり動かない

**場所:** `src/lib/notion/script-db.ts:73-86`、`src/app/api/sentence-study/route.ts:59-63`

- 初回学習時にDraft→Memorizingへ変更しない
- Perfect後に1文を忘れてもMemorizingへ戻さない
- Sentence CountとNext Reviewを更新しない
- 全文モードには「覚えた／忘れた」がない

### I-2 Review Logが不完全で、更新競合にも弱い

**場所:** `src/lib/notion/review-log.ts:6-43`

`Previous Interval`と`Next Interval`を保存していません。`sessionId:itemId`のcheck-then-createは同時実行時に重複し得ます。異なる端末から同じカードを回答すると、古いカード状態で後勝ち上書きされる可能性があります。

### I-3 日付判定がUTC基準で、Asia/Tokyoの早朝にずれる

**場所:** `phrase-db.ts:67`、`sentences-db.ts:58`、両review routeのNext Review計算

`toISOString().split('T')[0]`はUTC日付です。日本時間0:00〜8:59に「今日」の判定が前日になる可能性があります。

**修正:** `Asia/Tokyo`基準のcalendar date utilityを1か所に作り、取得・加算・保存で統一する。

### I-4 Sync Version／競合検出は実装されていない

**場所:** `phrase-db.ts:62`、`script-db.ts:49`

設計書はNotionの`last_edited_time`を使うとしていますが、コードは`Sync Version`というrich_textプロパティを読むだけで、値を書き込みません。実質常に空です。

**修正:** `page.last_edited_time`を直接マッピングするか、明確なversion番号をサーバー側で管理する。

### I-5 既存20件との重複排除が効かない可能性が高い

**場所:** `src/lib/notion/ingest.ts:14-24`

重複判定は`Normalized Phrase`だけを検索します。既存行の同プロパティが空のままだと、同じフレーズを再登録します。

**修正:** 既存行をバックフィルする移行を実行する。移行完了まではPhrase本体も正規化比較する。

### I-6 AI抽出・取り込みが要件の一部しか満たしていない

**場所:** `src/lib/ai/extract.ts`、`src/lib/notion/ingest.ts`、`src/app/api/ingest/route.ts`

- Tagsを抽出・登録していない
- Meeting Notes自動取り込みがない
- Source Typeが設計値と異なる`AI Transcript`
- サーバー側に8000文字制限がない
- AI結果の`example`型、文字長、件数を厳密検証していない
- 同じ既存表現にSource Referenceを追記しない
- 同時取り込みのcheck-then-createで重複し得る

### I-7 Script本文の自動分割・再同期が存在しない

要件上はScript Libraryの追加・変更を検出してSentence DBへ反映する必要がありますが、該当parser/sync処理がありません。全文表示もScript本文ではなくSentence DBに依存するため、Sentence行がなければ空表示です。

### I-8 PWAはインストール用の最低限で、オフライン学習は未実装

**場所:** `public/sw.js`

- HTML 3ルートしかprecacheしない
- APIデータのキャッシュがない
- オフライン回答キューがない
- cache-firstで更新確認をせず、デプロイ後に古いHTMLを保持し得る
- 保護ページを永続Cache Storageへ保存する
- Service Worker登録失敗を完全に無視する

オフラインが後続フェーズなら許容できますが、「PWA完成」「オフライン対応」とは言えません。

### I-9 UIコントラストがWCAG AAを満たさない組合せがある

計算結果:

- 白 / Blue `#2783DE`: 3.90:1
- 白 / Green `#46A171`: 3.18:1
- Secondary `#7D7A75` / White: 4.27:1
- Secondary / Surface `#F9F8F7`: 4.03:1
- Red `#E56458` / White: 3.34:1

16px通常文字では4.5:1が必要です。主要ボタン、補助文、エラー文に影響します。

### I-10 UI要件未達

- 12px/13px文字が多数あり、14px floorに未達
- textareaで`outline: none`だが代替focus-visibleがない
- フォントを指定するだけで実際にロードしていない
- ホームに「今日の学習を始める」1つの主操作がなく、Phrase/Scriptを人が選ぶ
- ホームに今日の件数・推定時間がない
- 方向・全文表示モードを記憶しない
- エラー画面に再試行操作がない
- Script 1文モードに前後文の表示がない
- PWAアイコンは青一色の正方形で、アプリ識別子として機能しにくい

### I-11 テストがSRS 6件だけ

認証、API入力検証、Notion mapper、重複排除、Mastered再出題、タイムゾーン、セッション終了、query refetch、Script遷移、Service Workerにテストがありません。

### I-12 設定・ドキュメントが現状と不一致

- READMEはNext.js 15だがpackage.jsonは16.2.11
- READMEはnext-pwa採用と書くが依存にない
- READMEのフェーズ進捗が全て未完了
- `completion-audit.md`は現コードより古く、認証/PWA未実装と記載する一方、現在はファイルが存在する
- 同監査はSRS更新を冪等と断定しているが、競合対策は未実装
- ZIPでは`.env.example`が見つからなかった。ただし圧縮時の除外パターンで除外された可能性あり
- READMEの必須環境変数にSentence DB、Review Log DB、Anthropic API keyが不足
- `.claude/settings.local.json`に個人PCの絶対パスと広いBash許可があり、Git除外推奨
- `tsconfig.tsbuildinfo`は配布物から除外推奨

---

## 良かった点

- Notion tokenとAnthropic keyはサーバー側ファイルからのみ参照
- ZIP内に実トークン、`.env`、秘密鍵は見つからなかった
- Notion SDK処理を`lib/notion`へ分離している
- DB名・プロパティ名を定数化している
- SRSアルゴリズムを独立関数にしている
- 二段階評価、両方向学習、Phrase/Script画面の骨格がある
- dark modeとreduced motionを考慮している
- 44px以上の主要タップ領域を概ね確保
- 既存Notionページ本文を破壊する処理は見つからなかった

---

## 修正順序

1. Auth.jsセッション検証へ置換し、全書込APIを保護
2. POST入力検証、対象DB所属確認、サーバー側現値取得
3. セッション配列固定・最終カード完了・refetch問題を修正
4. Mastered/Doneの期限再出題を修正
5. lockfileを再生成し`npm ci`を通す
6. Scriptステータス遷移とReview Logを修正
7. Asia/Tokyo日付utilityと競合制御を実装
8. 既存Normalized Phraseをバックフィル
9. AI取り込み・Script自動分割の要件不足を実装
10. テスト拡充後、lint/typecheck/test/build
11. 390pxとdesktopで全画面を目視QA
12. UIコントラスト、focus、フォント、アイコンを修正
13. README・schema・completion auditを現状へ更新

## リリース判定

**判定: HOLD**

少なくともB-1〜B-5を修正し、クリーン環境で`npm ci && npm run lint && npm run typecheck && npm test && npm run build`を通すまでは、外部公開を推奨しません。ローカルで自分だけが試す場合も、Notion書込前にB-2〜B-4の修正を推奨します。
