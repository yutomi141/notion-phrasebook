# Notion Schema

取得日：2026-07-24
取得元：Notion MCP（notion-fetch）

---

## Phrase DB

**Notion ID**：`2cf0b961-e486-80b5-af85-e933de95acaa`
**Data Source**：`collection://2cf0b961-e486-80dd-9cdb-000b17bb49c1`
**件数（取得時）**：20件

### Before（現行スキーマ）

| プロパティ名 | 型 | 備考 |
|---|---|---|
| `Phrase` | title | フレーズ本体 |
| `Meaning` | text | 日本語の意味 |
| `Example` | text | 例文 |
| `Tags` | multi_select | Logic / Opinion / Causality / Classification / Example / Source / Mechanism / Method / Hardware / Application / Efficiency / Robustness / Superiority / Result / General |
| `ステータス` | status | New（to_do）/ Reviewing（in_progress）/ Mastered（complete） |
| `English Activity Log` | relation | `collection://2de0b961-e486-8011-a30d-000b952722c8` への参照 |
| `日付` | rollup（readOnly） | English Activity Log の日付フィールドのロールアップ |

### After（拡張後スキーマ）

**既存プロパティは全て維持。以下を追加する。**

| プロパティ名 | 型 | 用途 |
|---|---|---|
| `Normalized Phrase` | text | 小文字化・空白正規化・句読点除去済みフレーズ。重複判定に使う |
| `Source Type` | select | 取り込み元の種類（Meeting Notes / Pasted Transcript / Manual） |
| `Source Reference` | text | 元会話ページのURLまたは識別子。追跡と重複排除に使う |
| `Last Reviewed` | date | 最終復習日時 |
| `Next Review` | date | 次回復習予定日 |
| `Interval Days` | number | 現在の復習間隔（日数）。SRSアルゴリズムが更新する |
| `Correct Streak` | number | 連続して「覚えた」を選んだ回数。Mastered判定に使う |
| `Review Count` | number | 累計復習回数 |
| `Forgotten Count` | number | 累計「忘れた」回数 |
| `Sync Version` | text | Notionの `last_edited_time` 文字列。競合検出に使う |

**ステータス遷移**

```
New ──────────────────────────────────────────────► Reviewing
（初回「覚えた」または「忘れた」で遷移）

Reviewing ──[Streak≥3かつInterval≥7日]──────────► Mastered

Mastered ──[「忘れた」]──────────────────────────► Reviewing
```

---

## Script Library

**Notion ID**：`2cf0b961-e486-80a1-aba8-e6da655b443f`
**Data Source**：`collection://2cf0b961-e486-8033-ad15-000b605a871d`
**件数（取得時）**：4件

### Before（現行スキーマ）

| プロパティ名 | 型 | 備考 |
|---|---|---|
| `名前` | title | スクリプト名 |
| `ステータス` | status | Draft（to_do）/ Memorizing（in_progress）/ Perfect（complete） |
| `タグ` | multi_select | Technical / Self-Intro / Email / Hobby |
| `作成日時` | created_time | 自動設定（readOnly） |

**ページ本文**：英文と日本語訳が自然文として格納されている。現在は構造化されていない。

### After（拡張後スキーマ）

**既存プロパティは全て維持。ページ本文も削除しない（人が読む完成版として維持）。**

| プロパティ名 | 型 | 用途 |
|---|---|---|
| `Last Reviewed` | date | 最終復習日時 |
| `Next Review` | date | 次回復習予定日 |
| `Sentence Count` | number | 構成文の総数（Script Sentences DBとの整合確認用） |
| `Sync Version` | text | 競合検出用（`last_edited_time`） |

> `Progress`（構成文の習得率）はScript Sentences DB構築後に計算式プロパティとして追加する。

**ステータス遷移**

```
Draft ──────────────────────────────────────────── ► Memorizing
（学習開始時に遷移）

Memorizing ──[全構成文がMastered]──────────────── ► Perfect

Perfect ──[いずれかの構成文が「忘れた」]─────── ► Memorizing
```

---

## Script Sentences DB（作成済み）

**Notion ID**：`5da82ae5-283a-4c0f-9699-1370ee84dc7c`
**Data Source**：`collection://3ba17855-d7ce-445f-b63c-6e63c5908e27`
**作成日**：2026-07-24
**件数**：27文（Self-Intro:6 / Quantum Computer Basic:8 / 剣道紹介スクリプト:9 / プログラミングと物理:4）

> **Status オプション名について**：Notion DDL の STATUS 型はオプション名を指定できないため、
> デフォルト名（`Not started` / `In progress` / `Done`）が使われています。
> コード側で `SENTENCE_STATUS` 定数にマッピングして吸収します（下記参照）。

### スキーマ

| プロパティ名 | 型 | Notion上の値 |
|---|---|---|
| `Sentence` | title | 英文 |
| `Meaning` | text | 日本語訳 |
| `Script` | relation → Script Library | 親スクリプトへの参照 |
| `Order` | number | 文の表示順（1始まり） |
| `Status` | status | `Not started`(=New) / `In progress`(=Reviewing) / `Done`(=Mastered) |
| `Last Reviewed` | date | 最終復習日時 |
| `Next Review` | date | 次回復習予定日 |
| `Interval Days` | number | 復習間隔（日数） |
| `Correct Streak` | number | 連続正解数 |
| `Review Count` | number | 累計復習回数 |
| `Forgotten Count` | number | 累計忘却回数 |

**初期データ作成ルール**
- Script Libraryの各ページ本文を読み取り、文単位で分割する
- 分割基準：`.` の後に大文字が続くパターン（英文末尾）。または明示的な改行区切り
- 既存Scriptが4件あるため、初回は約20〜40行が作成される見込み
- `Script` リレーションと `Order` は自動設定する
- 分割が不自然な場合は報告し、手動補正可能な構造にする

**重複防止**：`Script`(relation) + `Order`(number) の組み合わせでupsert処理する

---

## Review Log DB（作成済み）

**Notion ID**：`ad7be145-0c10-4f3a-8ce9-63087b2b0ae1`
**Data Source**：`collection://df53bb22-9627-4587-92af-adbe5961c5b8`
**作成日**：2026-07-24
**目的**：1回の自己評価を1行として記録する追記専用DB。集計値破損時の再計算源となる

### スキーマ

| プロパティ名 | 型 | 用途 |
|---|---|---|
| `Log Entry` | title | `{session_id}:{item_id}` 形式の冪等キー |
| `Reviewed At` | date | レビュー日時（ISO 8601） |
| `Item Type` | select（Phrase / Script Sentence） | 対象アイテムの種類 |
| `Phrase` | relation → Phrase DB | フレーズへの参照（Item TypeがPhraseの場合） |
| `Script Sentence` | relation → Script Sentences DB | 文への参照（Item TypeがScript Sentenceの場合） |
| `Result` | select（Remembered / Forgotten） | 自己評価結果 |
| `Direction` | select（EN→JA / JA→EN / Whole Script） | 出題方向 |
| `Previous Interval` | number | 回答前の復習間隔（日数） |
| `Next Interval` | number | 回答後の復習間隔（日数） |
| `Session ID` | text | 学習セッションのUUID |

**冪等性の保証**
- `Log Entry`（`{session_id}:{item_id}`）が既に存在する場合はスキップ
- 同一セッション・同一アイテムのログを重複作成しない

---

## 変更サマリー

| DB | 操作 | 内容 |
|---|---|---|
| Phrase DB | 拡張 | 既存7プロパティを維持し、10プロパティを追加 |
| Script Library | 拡張 | 既存4プロパティを維持し、4プロパティを追加 |
| Script Sentences DB | 新規作成 | 11プロパティ |
| Review Log DB | 新規作成 | 10プロパティ |

---

## コード内でのID管理

全てのDB IDとプロパティ名は `src/lib/schema/notion-ids.ts` に集約する。
ソース内の他の場所に文字列リテラルで書かない。

```typescript
// src/lib/schema/notion-ids.ts
export const NOTION_DB = {
  PHRASE:           process.env.NOTION_PHRASE_DB_ID!,
  SCRIPT_LIBRARY:   process.env.NOTION_SCRIPT_LIBRARY_DB_ID!,
  SCRIPT_SENTENCES: process.env.NOTION_SCRIPT_SENTENCES_DB_ID!,
  REVIEW_LOG:       process.env.NOTION_REVIEW_LOG_DB_ID!,
} as const;

export const PHRASE_PROPS = {
  PHRASE:            'Phrase',
  MEANING:           'Meaning',
  EXAMPLE:           'Example',
  TAGS:              'Tags',
  STATUS:            'ステータス',
  ACTIVITY_LOG:      'English Activity Log',
  DATE:              '日付',
  NORMALIZED_PHRASE: 'Normalized Phrase',
  SOURCE_TYPE:       'Source Type',
  SOURCE_REFERENCE:  'Source Reference',
  LAST_REVIEWED:     'Last Reviewed',
  NEXT_REVIEW:       'Next Review',
  INTERVAL_DAYS:     'Interval Days',
  CORRECT_STREAK:    'Correct Streak',
  REVIEW_COUNT:      'Review Count',
  FORGOTTEN_COUNT:   'Forgotten Count',
  SYNC_VERSION:      'Sync Version',
} as const;

export const SCRIPT_PROPS = {
  NAME:           '名前',
  STATUS:         'ステータス',
  TAGS:           'タグ',
  CREATED_AT:     '作成日時',
  LAST_REVIEWED:  'Last Reviewed',
  NEXT_REVIEW:    'Next Review',
  SENTENCE_COUNT: 'Sentence Count',
  SYNC_VERSION:   'Sync Version',
} as const;

export const SENTENCE_PROPS = {
  SENTENCE:       'Sentence',
  MEANING:        'Meaning',
  SCRIPT:         'Script',
  ORDER:          'Order',
  STATUS:         'Status',
  LAST_REVIEWED:  'Last Reviewed',
  NEXT_REVIEW:    'Next Review',
  INTERVAL_DAYS:  'Interval Days',
  CORRECT_STREAK: 'Correct Streak',
  REVIEW_COUNT:   'Review Count',
  FORGOTTEN_COUNT:'Forgotten Count',
} as const;

// Script Sentences DBのStatusはNotion DDLの制約でデフォルト名になっている
export const SENTENCE_STATUS = {
  NEW:       'Not started',
  REVIEWING: 'In progress',
  MASTERED:  'Done',
} as const;

export const REVIEW_LOG_PROPS = {
  LOG_ENTRY:         'Log Entry',
  REVIEWED_AT:       'Reviewed At',
  ITEM_TYPE:         'Item Type',
  PHRASE:            'Phrase',
  SCRIPT_SENTENCE:   'Script Sentence',
  RESULT:            'Result',
  DIRECTION:         'Direction',
  PREVIOUS_INTERVAL: 'Previous Interval',
  NEXT_INTERVAL:     'Next Interval',
  SESSION_ID:        'Session ID',
} as const;
```
