# Implementation Plan

作成日：2026-07-24
正本：English Flashcards App｜要件定義（Notion ID: `9b734b73-e323-4269-96fd-806098676de1`）

---

## 1. 技術スタック

### 採用構成

| レイヤー | 技術 | 選定理由 |
|---|---|---|
| フレームワーク | **Next.js 15 (App Router)** | API Routesにより単一リポジトリでサーバー処理を持てる。Notionトークンをクライアントに漏らさない構成が自然に実現できる |
| 言語 | **TypeScript 5** | 型安全性。NotionスキーマをTypeScriptの型として表現し、プロパティ名ミスをコンパイル時に検出する |
| スタイリング | **Tailwind CSS 4** | 要件定義のカラーパレット・余白スケールをCSS変数に落とし込んで一元管理できる |
| データフェッチ | **TanStack Query v5** | キャッシュ・再試行・楽観的更新が組み込まれており、オフライン復帰時の再送ロジックと相性が良い |
| Notion SDK | **@notionhq/client** | 公式SDK。サーバー側（API Routes）でのみ使用する |
| PWA | **next-pwa** | Service Workerの生成とmanifest管理。Workboxベース |
| テスト | **Vitest + React Testing Library** | Vite互換の高速テストランナー。SRSアルゴリズムと変換ロジックをユニットテストで保護する |
| Lint/Format | **ESLint + Prettier** | Next.jsデフォルト設定に準拠 |
| 認証 | **Auth.js v5 (NextAuth)** | Googleログインで本人確認。`AUTH_ALLOWED_EMAIL`で1アカウントに制限 |

### 採用しなかった選択肢

- **Vite + Express（別サーバー）**：デプロイが複雑になる。個人開発ではNext.jsのAll-in-oneが優位
- **Remix**：PWAエコシステムが Next.js より薄い
- **SvelteKit**：React/TypeScript生態系の恩恵を活かすためNext.jsを選択

---

## 2. アーキテクチャ：責務の分離

```
┌─────────────────────────────────────────┐
│           Browser (Client)              │
│  ・カード表示・タップ操作               │
│  ・TanStack Query でサーバーAPIを呼ぶ  │
│  ・Notionトークンは一切保持しない       │
└──────────────┬──────────────────────────┘
               │ HTTPS (JSON API)
┌──────────────▼──────────────────────────┐
│        Next.js API Routes (Server)      │
│  ・/api/sync      差分同期              │
│  ・/api/study     学習結果の反映        │
│  ・/api/ingest    会話取り込み          │
│  ・/api/auth      Auth.js               │
│  NOTION_TOKEN はここでのみ参照する      │
└──────────────┬──────────────────────────┘
               │ Notion API (HTTPS)
┌──────────────▼──────────────────────────┐
│              Notion                     │
│  Phrase DB / Script Library             │
│  Script Sentences DB / Review Log DB    │
└─────────────────────────────────────────┘
```

### フロントエンドの責務
- ユーザーインタラクション（カード表示・タップ）
- TanStack Query によるデータキャッシュと楽観的更新
- 未送信レビューキューの管理（IndexedDB）
- `prefers-color-scheme` / `prefers-reduced-motion` への追従

### バックエンド（API Routes）の責務
- Notionトークンを使った全Notion API呼び出し
- 差分同期（`last_edited_time` ベース）
- 重複判定・正規化
- Script本文の文分割
- レビュー結果のNotion書き込み

### Notion同期の責務
- 起動時・学習終了時・オンライン復帰時に自動同期
- `Sync Version`（`last_edited_time`）で競合検出
- 失敗時：指数バックオフ（初回1s → 最大64s）で自動再試行
- 同一操作の二重実行防止：各レビューに `session_id + item_id` の複合キーを付与

---

## 3. ディレクトリ構成

```
notion-phrasebook/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── sync/route.ts            # 差分同期
│   │   │   ├── study/route.ts           # レビュー結果反映
│   │   │   ├── ingest/route.ts          # 会話取り込み
│   │   │   └── auth/[...nextauth]/route.ts
│   │   ├── (study)/
│   │   │   ├── page.tsx                 # ホーム（今日の学習を始める）
│   │   │   ├── phrase/page.tsx          # フレーズ学習
│   │   │   └── script/
│   │   │       ├── full/page.tsx        # Script全文モード
│   │   │       └── sentence/page.tsx   # Script 1文モード
│   │   ├── list/page.tsx                # 一覧・検索
│   │   ├── settings/page.tsx
│   │   ├── layout.tsx
│   │   └── globals.css
│   ├── components/
│   │   ├── card/
│   │   │   ├── FlashCard.tsx
│   │   │   ├── CardFront.tsx
│   │   │   ├── CardBack.tsx
│   │   │   └── ReviewButtons.tsx        # 「覚えた」「忘れた」
│   │   ├── home/
│   │   │   ├── TodaySession.tsx
│   │   │   └── SyncStatus.tsx
│   │   ├── list/
│   │   │   ├── CardList.tsx
│   │   │   └── SearchFilter.tsx
│   │   └── ui/                          # 汎用コンポーネント
│   ├── lib/
│   │   ├── notion/
│   │   │   ├── client.ts               # Notion SDK初期化（server-only）
│   │   │   ├── phrase-db.ts
│   │   │   ├── script-db.ts
│   │   │   ├── sentences-db.ts
│   │   │   └── review-log-db.ts
│   │   ├── srs/
│   │   │   ├── algorithm.ts            # 間隔反復計算
│   │   │   └── config.ts               # 設定値（環境変数から読む）
│   │   ├── sync/
│   │   │   ├── sync-engine.ts
│   │   │   └── review-queue.ts         # IndexedDBキュー
│   │   └── schema/
│   │       └── notion-ids.ts           # 全DB ID・プロパティ名の定数
│   ├── hooks/
│   │   ├── useSync.ts
│   │   ├── useStudySession.ts
│   │   └── useCards.ts
│   └── types/
│       ├── phrase.ts
│       ├── script.ts
│       └── review.ts
├── tests/
│   ├── unit/
│   │   ├── srs/algorithm.test.ts
│   │   ├── notion/normalize.test.ts
│   │   └── sync/dedup.test.ts
│   └── integration/
├── docs/
│   ├── implementation-plan.md           # このファイル
│   └── notion-schema.md
├── public/
│   ├── manifest.json
│   └── icons/
├── .env.example
├── .gitignore
├── CLAUDE.md
├── README.md
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```

---

## 4. 確定版Notionスキーマ

詳細なBefore/Afterは `docs/notion-schema.md` に記載。

### 4.1 Phrase DB（既存拡張）

**維持するプロパティ**

| プロパティ | 型 |
|---|---|
| `Phrase` | title |
| `Meaning` | text |
| `Example` | text |
| `Tags` | multi_select |
| `ステータス` | status（New / Reviewing / Mastered） |
| `English Activity Log` | relation |
| `日付` | rollup |

**追加するプロパティ**

| プロパティ | 型 | 用途 |
|---|---|---|
| `Source Type` | select | Meeting Notes / Pasted Transcript / Manual |
| `Source Reference` | text | 元会話の識別子（重複判定・追跡用） |
| `Normalized Phrase` | text | 正規化済みフレーズ（重複判定用） |
| `Last Reviewed` | date | 最終復習日時 |
| `Next Review` | date | 次回復習日時 |
| `Interval Days` | number | 現在の復習間隔（日数） |
| `Correct Streak` | number | 連続「覚えた」回数 |
| `Review Count` | number | 累計復習回数 |
| `Forgotten Count` | number | 累計「忘れた」回数 |
| `Sync Version` | text | Notionの `last_edited_time`（競合検出用） |

### 4.2 Script Library（既存拡張）

**維持するプロパティ**：`名前`、`ステータス`（Draft/Memorizing/Perfect）、`タグ`、`作成日時`

**追加するプロパティ**

| プロパティ | 型 | 用途 |
|---|---|---|
| `Last Reviewed` | date | 最終復習日時 |
| `Next Review` | date | 次回復習日時 |
| `Progress` | number | 構成文の習得率（%、計算式プロパティ） |
| `Sentence Count` | number | 構成文の総数 |
| `Sync Version` | text | 競合検出用 |

### 4.3 Script Sentences DB（新規作成）

Script 1文モードのために本文を構造化した専用DB。

| プロパティ | 型 | 用途 |
|---|---|---|
| `Sentence` | title | 英文 |
| `Meaning` | text | 日本語訳 |
| `Script` | relation → Script Library | 親スクリプトへの参照 |
| `Order` | number | 表示順（1始まり） |
| `Status` | status（New/Reviewing/Mastered） | 文ごとの習熟状態 |
| `Last Reviewed` | date | 最終復習日時 |
| `Next Review` | date | 次回復習日時 |
| `Interval Days` | number | 復習間隔 |
| `Correct Streak` | number | 連続正解数 |
| `Review Count` | number | 累計復習回数 |
| `Forgotten Count` | number | 累計忘却回数 |

### 4.4 Review Log DB（新規作成）

1回の自己評価を1行に記録する追記専用DB。集計値が破損しても再計算できる。

| プロパティ | 型 | 用途 |
|---|---|---|
| `Log Entry` | title | `{session_id}:{item_id}` — 冪等キー |
| `Reviewed At` | date | レビュー日時 |
| `Item Type` | select（Phrase/Script Sentence） | 対象の種類 |
| `Phrase` | relation → Phrase DB | フレーズへの参照（任意） |
| `Script Sentence` | relation → Script Sentences DB | 文への参照（任意） |
| `Result` | select（Remembered/Forgotten） | 自己評価結果 |
| `Direction` | select（EN→JA/JA→EN/Whole Script） | 出題方向 |
| `Previous Interval` | number | 回答前の復習間隔 |
| `Next Interval` | number | 回答後の復習間隔 |
| `Session ID` | text | 学習セッションのUUID |

---

## 5. 既存データを保持する移行手順

### 原則
- 既存の行データと学習履歴は一切削除しない
- プロパティの追加のみ行い、既存プロパティを変更・削除しない
- 新規プロパティは `null`（空）でも既存データが壊れない設計

### 手順

**Step 1：スキーマ拡張前の検証**
```
1. Notion MCPでPhrase DBの現行スキーマを取得
2. 追加予定プロパティ名と型を確認（衝突がないか）
3. 既存行数を記録（拡張後に一致を確認する）
```

**Step 2：Phrase DBへのプロパティ追加**
```
追加するプロパティ（順番に1つずつ追加し、エラーがなければ次へ）：
Next Review (date), Last Reviewed (date),
Interval Days (number), Correct Streak (number),
Review Count (number), Forgotten Count (number),
Normalized Phrase (text), Source Type (select),
Source Reference (text), Sync Version (text)
```
- 既存行は新プロパティが空になるだけ。学習開始時に自動補完される

**Step 3：Script Libraryへのプロパティ追加**
```
Last Reviewed (date), Next Review (date),
Sentence Count (number), Sync Version (text)
```
- `Progress` は計算式プロパティ。Script Sentences DBが完成後に設定

**Step 4：Script Sentences DBの新規作成**
- Script Libraryの各エントリの本文を読み取り、文単位で行を作成
- 既存Script Libraryのページ本文は削除しない（人が読む完成版として維持）
- 文の分割ロジック：`。`または`.`の後に英文が続くパターンを検出

**Step 5：Review Log DBの新規作成**
- 完全に新規のDBのため、既存データへの影響なし

**ロールバック条件**
- 追加操作でエラーが発生した場合、その時点で中断し報告する
- 削除を伴わないため、スキーマ追加の取り消しは手動でのプロパティ削除で対応できる

---

## 6. 間隔反復アルゴリズム

### 設計方針

SM-2を2段階評価（覚えた/忘れた）向けに簡略化。説明可能かつ設定可能。

### アルゴリズム

```typescript
// src/lib/srs/config.ts から読み込む設定値
const SRS = {
  INITIAL_INTERVAL:  1,    // 初回復習間隔（日）
  SECOND_INTERVAL:   3,    // 1回目「覚えた」後の間隔（日）
  EASE_FACTOR:       2.5,  // 間隔の増加係数
  MIN_EASE:          1.3,  // ease_factorの下限
  EASE_DECREASE:     0.2,  // 「忘れた」時のease低下量
  MAX_INTERVAL:      365,  // 最大復習間隔（日）
  MASTERED_STREAK:   3,    // Masteredになる連続正解数
  MASTERED_INTERVAL: 7,    // Masteredになる最小間隔（日）
};

function calcNextReview(item: ReviewItem, result: 'remembered' | 'forgotten'): ReviewResult {
  if (result === 'forgotten') {
    return {
      intervalDays: SRS.INITIAL_INTERVAL,
      easeFactor: Math.max(SRS.MIN_EASE, item.easeFactor - SRS.EASE_DECREASE),
      correctStreak: 0,
      nextStatus: item.status === 'Mastered' ? 'Reviewing' : item.status,
    };
  }

  // remembered
  let nextInterval: number;
  if (item.reviewCount === 0) {
    nextInterval = SRS.INITIAL_INTERVAL;
  } else if (item.correctStreak === 0) {
    nextInterval = SRS.SECOND_INTERVAL;
  } else {
    nextInterval = Math.min(
      Math.round(item.intervalDays * item.easeFactor),
      SRS.MAX_INTERVAL
    );
  }

  const newStreak = item.correctStreak + 1;
  const isMastered = newStreak >= SRS.MASTERED_STREAK && nextInterval >= SRS.MASTERED_INTERVAL;

  return {
    intervalDays: nextInterval,
    easeFactor: item.easeFactor,
    correctStreak: newStreak,
    nextStatus: isMastered ? 'Mastered' : 'Reviewing',
  };
}
```

### 設定の変更方法

`.env` の以下を変更する。デフォルト値は上記の数値。

```
SRS_INITIAL_INTERVAL_DAYS=1
SRS_SECOND_INTERVAL_DAYS=3
SRS_EASE_FACTOR=2.5
SRS_MIN_EASE=1.3
SRS_EASE_DECREASE=0.2
SRS_MAX_INTERVAL_DAYS=365
SRS_MASTERED_STREAK=3
SRS_MASTERED_INTERVAL_DAYS=7
```

---

## 7. 同期・再試行・重複排除・冪等性の設計

### 同期タイミング
1. アプリ起動時（`/api/sync` を自動呼び出し）
2. 学習セッション終了時
3. `navigator.onLine` が `false → true` になったとき

### 差分取得（Notionからアプリへ）

Notion APIの `last_edited_time` をカーソルとして使用。
前回同期時刻をクライアントのlocalStorageに保存し、それ以降に変更されたページのみ取得する。

```typescript
// 疑似コード
const lastSync = localStorage.getItem('last_sync_time') ?? '2000-01-01';
const updated = await notion.databases.query({
  database_id: PHRASE_DB_ID,
  filter: { timestamp: 'last_edited_time', last_edited_time: { after: lastSync } }
});
```

### レビュー結果の送信（アプリからNotionへ）

1. レビュー完了時にIndexedDB（`review-queue`）へ追記
2. `/api/study` を呼び出してNotionへ反映
3. 成功時にキューから削除
4. 失敗時は指数バックオフで再試行（1s → 2s → 4s → ... → 64s上限）

### 重複排除

- **フレーズ重複**：`Normalized Phrase`（小文字化・トリム・空白正規化・句読点除去）で完全一致チェック
- **レビューLog重複**：`Log Entry` フィールドを `{session_id}:{item_id}` にしてNotionでunique扱い。既存の場合はスキップ
- **Script Sentence重複**：`Script`(relation) + `Order`(number) の組み合わせで判定

### 冪等性の保証

- 全API Routes はHTTP POSTでも冪等になるように設計
- `session_id`（UUIDv4）をセッション開始時に生成し、全リクエストに付与
- Notionへの書き込みは「存在すれば更新、なければ作成」のupsert方式

---

## 8. オンラインMVPの実装順序

### フェーズ1：データ契約の確定

**完了条件**
- [ ] Notion MCPでPhrase DBに追加プロパティが作成されている
- [ ] Script Sentences DBが作成され、既存Scriptの本文が文単位で分割されている
- [ ] Review Log DBが作成されている
- [ ] `src/lib/schema/notion-ids.ts` に全定数が定義されている

### フェーズ2：基本フレーズ学習（オンラインMVP）

**完了条件**
- [ ] Phrase DBの既存カードがホーム画面に表示される
- [ ] 英語→日本語・日本語→英語のモードを選択できる
- [ ] カードタップで裏面が表示される
- [ ] 「覚えた」「忘れた」をタップすると次回復習日とステータスがNotionに反映される
- [ ] 同期状態（済み/待ち/エラー）がUIに表示される
- [ ] 認証情報がブラウザに露出しない

### フェーズ3：Script対応

**完了条件**
- [ ] Script全文モードで英文と日本語訳を表示・切り替えできる
- [ ] Script 1文モードで文を順番に出題できる
- [ ] 各文の「覚えた」「忘れた」がScript Sentences DBに反映される
- [ ] Script全体のProgressが更新される

### フェーズ4：AI取り込み

**完了条件**
- [ ] 貼り付けた文字起こしテキストからフレーズを抽出できる
- [ ] AI Meeting Notesのページを入力として処理できる
- [ ] 重複判定により既存フレーズは重複作成されない
- [ ] 同じ取り込み単位を再処理しても二重登録されない

### フェーズ5：品質向上

**完了条件**
- [ ] Phrase・Meaning・Example・Script名で検索できる
- [ ] タグ・ステータス・期限超過で絞り込める
- [ ] 今日の学習件数・Mastered件数・連続学習日数が表示される
- [ ] SRSアルゴリズムのユニットテストが通る
- [ ] 重複排除・正規化のユニットテストが通る

### フェーズ6：オフライン対応

**完了条件**
- [ ] 同期済みカードをServiceWorkerでキャッシュ
- [ ] オフライン中も学習・自己評価ができる
- [ ] 復帰後にキューのレビュー結果がNotionへ送信される
- [ ] 競合時に学習履歴が失われない

---

## 9. テスト戦略

### ユニットテスト（Vitest）

重点対象：
- `src/lib/srs/algorithm.ts`：全分岐（初回/2回目/通常/Mastered昇格/Mastered降格）
- `src/lib/notion/normalize.ts`：正規化・重複判定ロジック
- `src/lib/sync/review-queue.ts`：エンキュー・デキュー・冪等性

### 型チェック（TypeScript）

- Notionプロパティとの型マッピングを型で表現
- `server-only` パッケージを使い、クライアントからのNotion clientインポートをコンパイル時エラーにする

### E2Eテスト（MVP後に追加）

- 学習セッションの基本フロー
- 同期失敗・復帰フロー

### 手動確認（各フェーズ完了時）

- デスクトップ + 390px幅スマートフォンで全主要画面を目視
- ライト・ダーク両モード
- WCAG AAコントラスト確認

---

## 10. 未確定事項の初期設定値

実装を止めない仮置き値。実データを見て調整する。

| 事項 | 初期設定値 | 変更方法 |
|---|---|---|
| Mastered判定：連続正解数 | 3回 | `SRS_MASTERED_STREAK` |
| Mastered判定：復習間隔 | 7日 | `SRS_MASTERED_INTERVAL_DAYS` |
| 初回復習間隔 | 1日 | `SRS_INITIAL_INTERVAL_DAYS` |
| 2回目の間隔 | 3日 | `SRS_SECOND_INTERVAL_DAYS` |
| ease係数初期値 | 2.5 | `SRS_EASE_FACTOR` |
| Review Logの書き込みタイミング | 毎回答直後に即時送信（キュー経由） | 実装レベルで変更可 |
| Script本文の文分割方法 | `.` または `。` で区切り、直後が大文字なら新文 | `src/lib/notion/script-parser.ts` |
