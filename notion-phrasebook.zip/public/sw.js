// キャッシュバージョン — ビルド時に next.config で置換するか手動で上げる
const CACHE_VERSION = 'v2';
const CACHE_STATIC = `phrasebook-static-${CACHE_VERSION}`;
const CACHE_API = `phrasebook-api-${CACHE_VERSION}`;

const PRECACHE_URLS = ['/', '/phrase', '/script', '/script/sentence'];

// 読み取り専用APIのSWRキャッシュ対象（maxAge秒）
const SWR_API_PATTERNS = [
  { pattern: /^\/api\/sync$/, maxAge: 300 },
  { pattern: /^\/api\/sentence-study$/, maxAge: 300 },
  { pattern: /^\/api\/scripts$/, maxAge: 300 },
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches
      .open(CACHE_STATIC)
      .then((c) => c.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k !== CACHE_STATIC && k !== CACHE_API)
            .map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;

  const url = new URL(e.request.url);
  const { pathname } = url;

  // SWRキャッシュ対象APIかチェック
  const swrRule = SWR_API_PATTERNS.find((r) => r.pattern.test(pathname));
  if (swrRule) {
    e.respondWith(swrFetch(e.request, swrRule.maxAge));
    return;
  }

  // その他APIはネットワーク優先
  if (pathname.startsWith('/api/')) {
    e.respondWith(
      fetch(e.request).catch(
        () =>
          new Response('{"error":"offline"}', {
            status: 503,
            headers: { 'Content-Type': 'application/json' },
          }),
      ),
    );
    return;
  }

  // 認証エンドポイントはキャッシュしない
  if (pathname.startsWith('/api/auth')) return;

  // 静的アセット: キャッシュ優先
  e.respondWith(
    caches.match(e.request).then((cached) => cached ?? fetchAndCache(e.request, CACHE_STATIC)),
  );
});

async function swrFetch(request, maxAge) {
  const cache = await caches.open(CACHE_API);
  const cached = await cache.match(request);

  if (cached) {
    const date = cached.headers.get('sw-cached-at');
    const age = date ? (Date.now() - Number(date)) / 1000 : Infinity;
    if (age < maxAge) return cached;
  }

  try {
    const response = await fetch(request);
    if (response.ok) {
      const clone = response.clone();
      const headers = new Headers(clone.headers);
      headers.set('sw-cached-at', String(Date.now()));
      const body = await clone.arrayBuffer();
      await cache.put(request, new Response(body, { status: clone.status, headers }));
    }
    return response;
  } catch {
    return (
      cached ??
      new Response('{"error":"offline"}', {
        status: 503,
        headers: { 'Content-Type': 'application/json' },
      })
    );
  }
}

async function fetchAndCache(request, cacheName) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    return new Response('Network error', { status: 503 });
  }
}
