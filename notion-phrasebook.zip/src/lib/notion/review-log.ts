import 'server-only';
import { notion } from './client';
import { NOTION_DB, REVIEW_LOG_PROPS } from '@/lib/schema/notion-ids';
import type { ReviewPayload } from '@/types';

export async function writeReviewLog(
  payload: ReviewPayload,
  previousInterval?: number,
  nextInterval?: number,
): Promise<void> {
  const logEntry = `${payload.sessionId}:${payload.itemId}`;

  // 冪等チェック: 同一エントリが存在したらスキップ
  const existing = await notion.databases.query({
    database_id: NOTION_DB.REVIEW_LOG,
    filter: {
      property: REVIEW_LOG_PROPS.LOG_ENTRY,
      title: { equals: logEntry },
    },
  });
  if (existing.results.length > 0) return;

  const properties: Record<string, unknown> = {
    [REVIEW_LOG_PROPS.LOG_ENTRY]: { title: [{ text: { content: logEntry } }] },
    [REVIEW_LOG_PROPS.REVIEWED_AT]: { date: { start: payload.reviewedAt } },
    [REVIEW_LOG_PROPS.ITEM_TYPE]: {
      select: { name: payload.itemType === 'phrase' ? 'Phrase' : 'Script Sentence' },
    },
    [REVIEW_LOG_PROPS.RESULT]: {
      select: { name: payload.result === 'remembered' ? 'Remembered' : 'Forgotten' },
    },
    [REVIEW_LOG_PROPS.DIRECTION]: {
      select: { name: payload.direction === 'EN_TO_JA' ? 'EN→JA' : 'JA→EN' },
    },
    [REVIEW_LOG_PROPS.SESSION_ID]: { rich_text: [{ text: { content: payload.sessionId } }] },
  };

  if (previousInterval !== undefined) {
    properties[REVIEW_LOG_PROPS.PREVIOUS_INTERVAL] = { number: previousInterval };
  }
  if (nextInterval !== undefined) {
    properties[REVIEW_LOG_PROPS.NEXT_INTERVAL] = { number: nextInterval };
  }

  if (payload.itemType === 'phrase') {
    properties[REVIEW_LOG_PROPS.PHRASE] = { relation: [{ id: payload.itemId }] };
  } else {
    properties[REVIEW_LOG_PROPS.SCRIPT_SENTENCE] = { relation: [{ id: payload.itemId }] };
  }

  await notion.pages.create({
    parent: { database_id: NOTION_DB.REVIEW_LOG },
    properties: properties as never,
  });
}
