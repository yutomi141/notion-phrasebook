import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { fetchPhraseSrsState, updatePhraseAfterReview } from '@/lib/notion/phrase-db';
import { writeReviewLog } from '@/lib/notion/review-log';
import { calculateNextInterval } from '@/lib/srs/algorithm';
import { addDaysJST, todayJST } from '@/lib/date';
import type { ReviewPayload } from '@/types';

interface RequestBody {
  payload: ReviewPayload;
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let body: RequestBody;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const { payload } = body;
  if (!payload?.itemId || !payload?.result || !payload?.sessionId) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }
  if (payload.result !== 'remembered' && payload.result !== 'forgotten') {
    return NextResponse.json({ error: 'Invalid result value' }, { status: 400 });
  }

  try {
    const state = await fetchPhraseSrsState(payload.itemId);
    if (!state) {
      return NextResponse.json({ error: 'Phrase not found' }, { status: 404 });
    }

    const previousInterval = state.intervalDays;
    const srs = calculateNextInterval(payload.result, state.intervalDays, state.correctStreak);
    const nextReviewDate = addDaysJST(new Date(), srs.nextIntervalDays);
    const reviewedAt = todayJST();

    const newReviewCount = state.reviewCount + 1;
    const newForgottenCount =
      payload.result === 'forgotten' ? state.forgottenCount + 1 : state.forgottenCount;

    await Promise.all([
      updatePhraseAfterReview(
        payload.itemId,
        srs.newStatus,
        srs.nextIntervalDays,
        srs.newStreak,
        nextReviewDate,
        reviewedAt,
        newReviewCount,
        newForgottenCount,
      ),
      writeReviewLog(payload, previousInterval, srs.nextIntervalDays),
    ]);

    return NextResponse.json({
      ok: true,
      nextReview: nextReviewDate,
      newStatus: srs.newStatus,
      newInterval: srs.nextIntervalDays,
    });
  } catch (error) {
    console.error('[study] Notion update error:', error);
    return NextResponse.json({ error: 'Failed to record review' }, { status: 500 });
  }
}
