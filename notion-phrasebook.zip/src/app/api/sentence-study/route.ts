import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import {
  fetchDueSentences,
  fetchSentenceSrsState,
  updateSentenceAfterReview,
  countSentencesForScript,
} from '@/lib/notion/sentences-db';
import { fetchScriptStatus, updateScriptAfterReview } from '@/lib/notion/script-db';
import { writeReviewLog } from '@/lib/notion/review-log';
import { calculateNextInterval } from '@/lib/srs/algorithm';
import { addDaysJST, todayJST } from '@/lib/date';
import type { ReviewPayload } from '@/types';

export async function GET() {
  try {
    const sentences = await fetchDueSentences();
    return NextResponse.json({ sentences });
  } catch (error) {
    console.error('[sentence-study] Notion fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch sentences' }, { status: 500 });
  }
}

interface RequestBody {
  payload: ReviewPayload;
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let body: RequestBody;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const { payload } = body;
  if (!payload?.itemId || !payload?.result || !payload?.sessionId) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }
  if (payload.result !== 'remembered' && payload.result !== 'forgotten') {
    return NextResponse.json({ error: 'Invalid result value' }, { status: 400 });
  }

  try {
    const state = await fetchSentenceSrsState(payload.itemId);
    if (!state) {
      return NextResponse.json({ error: 'Sentence not found' }, { status: 404 });
    }

    const previousInterval = state.intervalDays;
    const srs = calculateNextInterval(payload.result, state.intervalDays, state.correctStreak);
    const nextReviewDate = addDaysJST(new Date(), srs.nextIntervalDays);
    const reviewedAt = todayJST();

    const newReviewCount = state.reviewCount + 1;
    const newForgottenCount =
      payload.result === 'forgotten' ? state.forgottenCount + 1 : state.forgottenCount;

    await updateSentenceAfterReview(
      payload.itemId,
      srs.newStatus,
      srs.nextIntervalDays,
      srs.newStreak,
      nextReviewDate,
      reviewedAt,
      newReviewCount,
      newForgottenCount,
    );

    if (state.scriptId) {
      const [{ done, total }, currentScriptStatus] = await Promise.all([
        countSentencesForScript(state.scriptId),
        fetchScriptStatus(state.scriptId),
      ]);
      await updateScriptAfterReview(
        state.scriptId,
        reviewedAt,
        done,
        total,
        currentScriptStatus,
        payload.result,
        nextReviewDate,
      );
    }

    await writeReviewLog(payload, previousInterval, srs.nextIntervalDays);

    return NextResponse.json({
      ok: true,
      nextReview: nextReviewDate,
      newStatus: srs.newStatus,
      newInterval: srs.nextIntervalDays,
    });
  } catch (error) {
    console.error('[sentence-study] Notion update error:', error);
    return NextResponse.json({ error: 'Failed to record review' }, { status: 500 });
  }
}
